using System;

namespace Inceptum.Workflow.Fluent
{
    

    class NodeDescriptor<TContext> : IExecutionPoint<TContext>
    {
        private readonly WorkflowGraph<TContext> m_Graph;
        private readonly IGraphNode<TContext> m_Node;

        public NodeDescriptor(WorkflowGraph<TContext> graph, IGraphNode<TContext> node)
        {
            m_Node = node;
            m_Graph = graph;
        }


        public IExecutionPoint<TContext> Do<TActivity>(string name) where TActivity : IActivity<TContext>
        {
 
            var node = m_Graph.CreateNode<TActivity>(name, m_Node,null);
            var descriptor = new NodeDescriptor<TContext>(m_Graph, node);
            return descriptor;
 
        }

        public void Continue(string nodeName)
        {
            m_Graph.CreateEdge(m_Node, nodeName, null);
        }

        public IDecision<TContext, TParam> Decision<TParam>(Func<TContext, TParam> paramGetter, string name)
        {
            var node = m_Graph.CreateNode(name, m_Node, null);
            var descriptor = new DecisionDescriptor<TContext, TParam>(m_Graph, node, paramGetter);
            return descriptor;
        }

        public IDecision<TContext, TParam> Decision<TParam>(Func<TContext, TParam> paramGetter)
        {
            var descriptor = new DecisionDescriptor<TContext, TParam>(m_Graph, m_Node, paramGetter);
            return descriptor;
        }
    }
}