using System;

namespace Inceptum.Workflow.Fluent
{
    class ConstraintDescriptor<TContext, TParam> : IConstraint<TContext, TParam>
    {
        private readonly WorkflowGraph<TContext> m_Graph;
        private readonly IGraphNode<TContext> m_Node;
        private readonly Func<TContext, bool> m_Condition;
        private readonly DecisionDescriptor<TContext, TParam> m_DecisionDescriptor;
        private string m_Description;

        public ConstraintDescriptor(WorkflowGraph<TContext> graph, IGraphNode<TContext> node, Func<TContext, bool> condition, DecisionDescriptor<TContext, TParam> decisionDescriptor, string description)
        {
            m_Description = description;
            m_DecisionDescriptor = decisionDescriptor;
            m_Condition = condition;
            m_Node = node;
            m_Graph = graph;
        }

        public IDecision<TContext, TParam> Execute(string branchName,Action<IExecutionPoint<TContext>> branch)
        {
            branch(new NodeDescriptor<TContext>(m_Graph, m_Graph.CreateNode(branchName, m_Node, m_Condition)));
            return m_DecisionDescriptor;
        }

        public IDecision<TContext, TParam> Execute(string branchName)
        {
            m_Graph.CreateEdge(m_Node, branchName, m_Condition, m_Description);
            return m_DecisionDescriptor;
        }
    }
}