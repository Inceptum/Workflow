namespace Inceptum.Workflow.Fluent
{
    public static class WorkflowGraphExtensions
    {
        public static IExecutionPoint<TContext> Branch<TContext>(this WorkflowGraph<TContext> graph, string branchName)
        {
            var node = graph.CreateNode(branchName, null);
            return new NodeDescriptor<TContext>(graph, node);
        }
        public static IExecutionPoint<TContext> Branch<TContext>(this WorkflowGraph<TContext> graph)
        {
            return new NodeDescriptor<TContext>(graph, null);
        }

        public static IDecision<TContext, TContext> Decision<TContext>(this IExecutionPoint<TContext> node, string name)
        {
            return node.Decision(context => context,name);
        }
 

        public static IExecutionPoint<TContext> Start<TContext>(this WorkflowGraph<TContext> graph)
        {
            return new NodeDescriptor<TContext>(graph, graph.Start);
        }

    }
}