using System;

namespace Inceptum.Workflow.Fluent
{
    public interface IDecision<TContext, TParam>  
    {
        IConstraint<TContext, TParam> Constraint(string description, Func<TParam, bool> condition);
    }
}