using System;

namespace Inceptum.Workflow.Fluent
{
    class DecisionDescriptor<TContext, TParam> : IDecision<TContext, TParam>
    {
        private readonly WorkflowGraph<TContext> m_Graph;
        private readonly IGraphNode<TContext> m_Node;
        private readonly Func<TContext, TParam> m_ParamGetter;

        public DecisionDescriptor(WorkflowGraph<TContext> graph, IGraphNode<TContext> node, Func<TContext, TParam> paramGetter)
        {
            m_ParamGetter = paramGetter;
            m_Node = node;
            m_Graph = graph;
        }

        public IConstraint<TContext, TParam> Constraint(string description, Func<TParam, bool> condition)
        {
            return new ConstraintDescriptor<TContext, TParam>(m_Graph, m_Node, context => condition(m_ParamGetter(context)), this, description);
        }
    }
}