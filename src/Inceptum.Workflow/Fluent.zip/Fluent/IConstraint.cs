using System;

namespace Inceptum.Workflow.Fluent
{
    public interface IConstraint<TContext, TParam>
    {
        IDecision<TContext, TParam> Execute(string branchName,Action<IExecutionPoint<TContext>> branch);
        IDecision<TContext, TParam> Execute(string branchName);
        
    }
}