using System;

namespace Inceptum.Workflow.Fluent
{
    public interface IExecutionPoint<TContext>
    {
        IExecutionPoint<TContext> Do<TActivity>(string name=null) where TActivity : IActivity<TContext>;
        IDecision<TContext, TParam> Decision<TParam>(Func<TContext, TParam> param, string name);
        void Continue(string nodeName);
    }
}